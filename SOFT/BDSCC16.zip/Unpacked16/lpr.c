/*
	LPR.C: Intelligent line printer driver

	Written by Leor Zolman, May 28, 1980
	Modifed for use with DATE.C utility and BDS C v1.6, May 1986

	   Usage: lpr [-l#] [-o] <filename1> [<filename2>] [<filename3>] ...

		# is number of lines per page, defaults to PGLEN
		-o disables the feature that starts each file on an odd page

	First prints all files named on the command line, then asks for
	names of more files to print until a null line is typed.

	Control-Q aborts current printing and goes to next file.

	If more than one file is printed, then by default LPR starts each
	file on an odd page (for consistency of orientation on fan-fold paper)

	Tabs are expanded into spaces.
*/

#include <stdio.h>

#define DATEFILE "0/A:DATE.SYS"	/* if DATE.C date system is being used */

#define FF 0x0c		/* formfeed character, or zero if not supported */
#define PGLEN 80	/* default no. of lines per page */

int colno, linesleft, pglen;

main(argc,argv)
char **argv;
{
	int i, pgno, fd, odd, first;
	char date[30], linebuf[MAXLINE];/* date and line buffers */
	char fnbuf[30], *fname;		/* filename buffer & ptr */
	FILE *fp;			/* buffered input pointer*/
	char *gets();

	pgno = colno = 0;
	pglen = PGLEN;
	first = odd = TRUE;

	if ((fp = fopen(DATEFILE, "r")) == NULL) {
		printf("What is today's date? ");
		gets(date);
	} else {
		fgets(date, 30, fp);
		fclose(fp);
	}
	i = strlen(date) - 1;
	if (date[i] == '\n')
		date[i] = '\0';

	while (1)
	{
		if (argc-1)
		 {
			fname = *++argv;
			argc--;
			if (*fname == '-')
			{
			   switch(*++fname)
			   {
			     case 'L':  pglen = atoi(++fname);
					printf("Printing %d lines per page.\n",
							pglen);
					break;

			     case 'O':	odd = FALSE;
					break;

			     default:   printf("Unknown option: -%c\n",*fname);
					exit();
			   }
			}
		 }
		else
		 {
			printf("\nEnter file to print, or CR if done: ");
			if (!*(fname = gets(fnbuf)))
				break;
		 }

		if ((fp = fopen(fname,"r")) == NULL)
		 {
			printf("Can't open %s\n",fname);
			continue;
		 }
		else printf("\nPrinting %-13s",fname);

		if (!first && odd && pgno % 2)
			formfeed();
		linesleft = PGLEN; 
		for (pgno = 1; ; pgno++)
		 {
			putchar('*');
			sprintf(linebuf,"%28s%-13s%5s%-3d%20s\n\n\n",
				"file: ",fname,"page ",pgno,date);
			linepr(linebuf);

		loop:	if (!fgets(linebuf, MAXLINE, fp)) break;
			if (kbhit() && getchar() == 0x11) break;
			if (linepr(linebuf)) continue;
			if (linesleft > 2) goto loop;
			formfeed();
		 }
		formfeed();
		fabort(fd);
		first = FALSE;		/* no longer on first file */
	}
}

/*
	Print a line of text out on the list device, and
	return true if a formfeed was encountered in the
	text.
*/

linepr(string)
char *string;
{
	char c, ffflag;
	ffflag = 0;
	while (c = *string++ & 0x7f)
	  switch (c) {
	    case FF:
		ffflag = 1;
		break;
	    case '\n':	
		putlpr('\r');
		putlpr('\n');
		colno = 0;
		linesleft--;
		break;

	    case '\t':
		do {
		  putlpr(' ');
		  colno++;
		} while (colno % 8);
		break;

	    default:					
		putlpr(c);
		colno++;
	}
	if (ffflag) formfeed();
	return ffflag;
}

putlpr(c)
char c;
{
	bios(5,c);
}

formfeed()
{
	if (FF)
		putlpr(FF);
	else
		while (linesleft--)
			putlpr('\n');
	linesleft = pglen;
}

#include "stdio.h"
main(argc,argv)
{
printf("Today is perfect day to writting Hello World II(12.06.2020)\n");
char *filnam;
unsigned filsiz;
int q, fd;
char txtbuf[128];	/* sector buffer */
filnam = "YEAH.TXT";
if ((fd = open(filnam, 0)) == ERROR)
	{
		printf("Cannot open %s\n",filnam);
		exit();
	}
filsiz = cfsize(fd);		/* find size of file in sectors */
printf(filsiz);
printf("\n");
read(fd, txtbuf, 1);
for (q = 0; q < 128; q++)
{
putchar(txtbuf[q]);
}	
close(fd);
}




main(argc,argv)
char **argv;
{
int i;
for (i = 1; i < argc; i++)
printf("Arg #%d = %s\n",argv[i]);
}
/*
	Maintains a system date file for systems lacking real-time clock.
	The date file (DATEFILE below) is just a line of text containing
	the last date set. It  is recognized by the LPR.C utility, so the
	current date always gets printed on listings.

	Usage:
		date			;print current system date

		date <mo/day/yr>	;set new date (all numerals)
	or	date <mo day, yr>	;set new date (alphabetic month,
					;		abbreviations OK)
	or	date +n			;bump by n days (n defaults to 1)
*/

#include <stdio.h>

#define DATEFILE "0/A:DATE.SYS"
char linebuf[MAXLINE];
char *months[12];
int days[12];
int month_no;

main(argc,argv)
char **argv;
{
	FILE *fp;
	int i, j;
	char month[30];
	int day, year;

	initptr(months, "January", "February", "March", "April", "May",
			"June", "July", "August", "September", "October",
			"November", "December", NULL);

	initw(days,"31,28,31,30,31,30,31,31,30,31,30,31");

	if (argc == 1 || argv[1][0] == '+')
	{
		if ((fp = fopen(DATEFILE, "r")) == NULL)
			goto newfile;
		if (fscanf(fp, "%s %d, %d", &month, &day, &year) != 3)
		{
			puts("Illegal date format.\n");
			fclose(fp);
			goto newfile;
		}

		if (argc == 1)
		{
	  say_date:	printf("Current date is: %s %d, %d\n",month,day,year);
			fclose(fp);
			exit();
		}
		else
		{

			if (!(j = atoi(&argv[1][1])))
				j++;

			for (i = 0; i < 12; i++)
				if (!strcmp(month, months[i]))
					month_no = i;

			for (i = 0; i < j; i++)
			{
			    if (++day > days[month_no])
			    {
				  if (leap(year) && month_no == 2 && day == 29)
					continue;
				  day = 1;
				  if (++month_no > 11)
				  {
					month_no = 0;
					year++;
				  }
			    }
			}

			strcpy(month, months[month_no]);

			fclose(fp);
			if ((fp = fopen(DATEFILE, "w")) == NULL)
				exit(printf("Can't create %s\n",DATEFILE));
			fprintf(fp, "%s %d, %d\n", month, day, year);
			printf("New date is: %s %d, %d\n",month, day, year);
			fclose(fp);
			exit();	
		}

	}

     newfile:	if (argc == 1)
		{
			printf("What is today's date? ");
			gets(linebuf);
		}
		else
		{
			*linebuf = '\0';
			for (i = 1; i < argc; i++)
			{
				strcat(linebuf, argv[i]);
				strcat(linebuf, " ");
			}
		}

		if ((fp = fopen(DATEFILE, "w")) == NULL)
			exit(printf("Can't create %s\n",DATEFILE));
		printf("Creating new system date file '%s'\n",DATEFILE);

		if (sscanf(linebuf, "%d/%d/%d", &i, &day, &year) == 3)
			strcpy(month, months[i-1]);
		else if (sscanf(linebuf,"%s %d, %d",&month, &day, &year) == 3)
		{
			for (i = 0; i < 12; i++)
			{
			   for (j = 0; j < 3; j++)
				if (tolower(month[j]) != tolower(months[i][j]))
					goto try_next;
			   strcpy(month, months[i]);
			   goto write_date;
		try_next:;
			}
		}
			   
	write_date:
		if (year < 100)
			year += 1900;
		fprintf(fp, "%s %d, %d\n", month, day, year);
		goto say_date;
}

int leap(year)
int year;
{
	if (!(year % 400))	/* if year multiple of 400, IS a leap year   */
		return TRUE;
	if (!(year % 100))	/* else if multiple of 100, is NOT leap year */
		return FALSE;
	return (!(year % 4));	/* else IS a leap year if multiple of 4	     */
}

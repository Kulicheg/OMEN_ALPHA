#include "stdio.h"
main(argc,argv)
{
int q;
for (q = 0; q < 10000; q++);
{
syscout ('*');
}
}
/*
	CMODEM.C	v1.6	<Sep 24, 1986>

	Files of this program:	CMODEM.H, CMODEM.C, CMODEM2.C

	Modified for BDS C v1.6 by Leor Zolman, 10/82, 2/83, 9/86

	A telecommunications program using Ward Christensen's
	"MODEM" File Transfer Protocol.

 	Modified by Nigel Harrison and Leor Zolman from XMODEM.C,
	which was written by:  Jack M. Wierda,
               modified by Roderick W. Hart and William D. Earnest

	Added "CRC" file transfer protocol and cancelation via Control-X
	during file xfers. <Stefan Badstuebner	4 Mar 83>

	Compilation & linkage:
		cc cmodem.c
		cc cmodem2.c
		clink cmodem cmodem2 -n

	Note that the Modem port interfaces are defined in HARDWARE.H,
	which must be configured with the correct values for your system.

	CMODEM now distinguishes between several different modes of
	operation: "terminal" mode (full duplex), "host" mode, and 
	"half-duplex" mode, as follows (designed by Stefan Badstuebner):
	----------------------------------------------------------------
	TERMINAL MODE:		keyboard(char) ---> MoDem

				MoDem(char)    ---> CRT
	----------------------------------------------------------------
	ECHO (HOST) MODE:	keyboard(char) ---> MoDem
						`---> CRT
			If (char == CR).... LF ---> MoDem
						`---> CRT

				MoDem(char)    ---> CRT
						`---> MoDem
			If (char == CR).... LF ---> CRT
						`---> MoDem
	----------------------------------------------------------------
	1/2 DUPLEX MODE:	keyboard(char) ---> MoDem
						`---> CRT
			If (char == CR).... LF ---> CRT

				MoDem(char)    ---> CRT
	----------------------------------------------------------------
*/

#include <stdio.h>
#include <hardware.h>
#include "cmodem.h"


int kbhit()	/* test for console character available: */
{
	return bios(2);
}

int getch()	/* get char from console raw, no echo */
{
	while (!kbhit());
	return bios(3) & 0x7f;
}

int getchar()	/* get console char with echo, expand CR to CRLF locally: */
{
	char c;

	putchar(c = getch());
	if (c == '\r')
		putchar('\n');	
	return c;
}

putchar(c)	/* write char to console, expand LF to CRLF: */
{
	if (c == '\n') putchar('\r'); 
	bios(4,c);
}

send(data)	/* send char to modem */
char data;
{
	while(!MOD_TBE)
		;
	MOD_TDATA(data);
}

main(argc,argv)
char **argv;
{
	unsigned u;
	int i;
	char *p;			/* scratch pointer */
	char in;
	char *alloc();			/* storage allocator */
	int baudrate;
	int menu_flag;

	fflg = hostflg = halfdup = FALSE;

	baudrate = 0;			/* unknown baud rate */
	menu_flag = TRUE;

	for (u = 40000; u > 3000; u -= 500)
	{
		if (!(txtbuf = alloc(u)))
			continue;
		free(txtbuf);
		txtbuf = alloc(u - (NSECTS * SECSIZ + 2000));
		lastloc = alloc(0);
		break;
	}

   while(1)
   {
	if (menu_flag)
	{  puts(CLEARS);
	   printf("CMODEM ver 1.6   <Sep 1986>\n\n");

	   printf("T: Terminal mode - no text collection\n");
	   printf("X: terminal mode with teXt collection\n");
	   printf("\tIn terminal mode:\n");
	   printf("\t\tSPECIAL (control-^): return to menu\n");
	   printf("H: toggle Host mode (for user-user typing) (now: %s)\n",
					hostflg ? "ENABLED" : "disabled");
	   printf("G: toGgle half-duplex system mode (now: %s duplex)\n",
					halfdup ? "HALF" : "full");
	   printf("F: Flush text buffer to text collection file\n");
	   printf("C: flush and Close text collection file\n");
	   printf("M: display Menu\n");
	   printf("U: select cp/m User area\n");
	   printf("V: select cp/m driVe\n");
	   printf("D: print Directory for current drive and user area\n");
	   printf("S: Send a file, MODEM protocol\n");
	   printf("R: Receive a file, MODEM protocol\n");   
	   printf("B: select Baud rate (currently ");
		   if (baudrate)
			printf("running at %d baud",baudrate);
		   else
			printf("unchanged from last usage");
		   puts(")\n");

	   printf("Q: quit\n");
	   printf("SPECIAL: send SPECIAL char to modem\n");
	}
	menu_flag = FALSE;

	printf("\nCommand: ");

	in = toupper(getchar());
	putchar('\n');

     switch(in)
     {
	case 'U':
		printf("Switch to user area: ");
		bdos(32,atoi(gets(linebuf)));
		break;

	case 'V':
		printf("Switch to drive: ");
		bdos(14,toupper(getchar()) - 'A');
		break;

	case 'D':
		dodir();
		goto wait2;

	case SPECIAL:
		send(SPECIAL);
		break;

	case 'T':
		terminal();
		break;

	case 'M':
	case '?':
		menu_flag = TRUE;
		break;

	case 'X':
     if (fflg)
	printf("(Text collection in effect, file = '%s')\n", fnambuf);
     else
     {
	puts("Collection text filename = ");
	getname(fnambuf);

	puts("Wait...\n");
	if ((fp = fopen(fnambuf,"r")) == NULL)	/* if doesn't exist, */
		goto newfile;			/* go create it 	 */
	else					/* else query further	 */
	{
		fclose(fp);
		printf("\nFile already exists; do you want to ");
		if(ask("overwrite it"))
		{
	 newfile:  if ((fp = fopen(fnambuf, "w")) == NULL) /* Make new file */
		   {
			printf("\nCan't create %s", fnambuf);
			goto wait;
		   }
		}
		else if (ask("Do you want to append to it")) /* append to it */
		{
		   if ((fp = fopen(fnambuf,"a")) == NULL)
		   {
			printf("\nCan't append for some reason\n");
			goto wait;
		   }
		}
		else
		{
			printf("File operations aborted.\n");
			goto wait;
		}
	}
	
	fflg = TRUE;
	txtptr = txtbuf;
	printf("\nText buffer size = %u bytes. When there are less than\n",
			lastloc - txtbuf);
	printf("1000 bytes left in the buffer, a BELL will sound every\n");
	printf("16 characters to remind you to halt downloading and flush\n");
	printf("the text buffer (using the 'F' command.)\n");
     }

	printf("\n\nReady\n");

	while(1)
	{	if(MOD_RDA)
		{	putchar (in = MOD_RDATA & 0x7F);
			if (hostflg)
			{
				send(in);
				if (in == '\r')
				{
					send('\n');
					putchar('\n');
				}
			}

			if (txtptr != lastloc)
				*txtptr++ = in;
			u = lastloc - txtptr;
			if (u < 1000)	
			{	/* Sound bell every 16 chars if buffer full */
			    i = txtptr;
			    if (!(i & 0xf))
				putchar(BELL);			
			}
		}
		if(kbhit())
		{
			in = getch();
			if(in == SPECIAL)
				break;
			else
				send(in);
			if (hostflg || halfdup)
			{
				putchar(in);
				if (in == '\r')
				{
					putchar('\n');
					if (hostflg)
						send('\n');
				}
			}	
		}
	}
	break;

     case 'S':
     case 'R':
	printf("File to %s = ", (in == 'S') ? "send" : "receive");
	getname(linebuf);

	if (setjmp(jump_buf))		/* Allow keyboard cancel */
	{
		fclose(fp);
		printf("\nCanceled!\n");
		goto send_beep;
	}

	if(in == 'R')
	{
		if (ask("CRC mode"))
		   crc_flag = TRUE;
		else
		   crc_flag = FALSE;

		rcv_file(linebuf);
	}
	else
	{
		if((fp = fopen(linebuf, "r")) == NULL)
		{	printf("Can't open %s\n", linebuf);
			goto wait;
		}
		sendfile(linebuf);
	}

   send_beep:
	putchar(BELL);			/* beep when done */
	break;

     case 'F':
	flush();
	goto wait;

     case 'G':
	if (halfdup = !halfdup)
	{
		puts("Going into half duplex mode\n");
		if (hostflg) {
			puts("(HOST mode is being automatically disabled)\n");
			hostflg = FALSE;
		}
		goto wait;
	}
	goto Hterm;

     case 'H':
	if (hostflg = !hostflg)
	{
		puts("Going into HOST (user-user communication) mode\n");
		if (halfdup)
		{
		  puts("(HALF DUPLEX mode is being automatically disabled)\n");
			halfdup = FALSE;
		}
		goto wait;
	}

	Hterm:	puts("Going back to normal terminal mode\n");
		goto wait;

     case 'B':	/**** This section is left for the user to configure ****
		* 1) ask the user what baudrate to switch to,		*
		* 2) set the "baudrate" variable equal the new rate    *
		* 3) actually set the baudrate in whichever way is	*
		*    appropriate to your hardware.			*
		* Note that the "baudrate" variable comes up equal to	*
		* 0 to indicate that no explicit baud rate has been	*
		* selected by the user (i.e., the baudrate is in what-	*
		* ever state it was in before CMODEM was invoked)	*
		*********************************************************/

	puts("Baudrate selection is left for the user to configure.\n");
	puts("Look for \"case 'B':\" in CMODEM.C\n");
	goto wait;

     case 'Q':
	if (fflg)
	{
		printf("\nSave file \"%s\" to ",fnambuf);
		if (ask("disk"))
		{	flush();
			fclose(fp);
		}
	}
	exit(0);

     case 'C':
	if (fflg)
	{
		printf("Closing %s...",fnambuf);
		flush();
		fclose(fp);
		fflg = FALSE;
	}
	else puts("No currently active text collection file\n");

 wait: 	putchar('\n');
 wait2: puts("\nHit any key to return to menu: ");
	menu_flag = TRUE;
	getchar();
     }
   }
}

flush()		/* flush text buffer to output file */
{
	char *cptr;

	for(cptr = txtbuf; cptr < txtptr; cptr++)
		if (fputc(*cptr, fp) == ERROR)
			printf("\n\7Error writing txt, disk full?\n");
}

dodir()
{
	char dmapos;		/* value returned by search calls */
	char first_time;	/* used in search routine */
	char tmpfn[20];		/* temp filename buffer */
	char fcb[36];
	int colno;		/* column count */
	int i;
	char *gets();
	char name[30];
	int drive;
		
	bdos(26,0x80);	/* ensure default DMA after read/write */
	printf("Enter ambiguous filename to find, or <cr> to list all: ");
	if (!*gets(name))
		setfcb(fcb,"*.*");
	else 
		setfcb(fcb,name);

	drive= (fcb[0]==0 ? bdos(25) : fcb[0]-1 ) ;

	puts(CLEARS);
	printf("Directory for Drive %c, user area %d:\n\n",
			drive+'A', bdos(32,0xff));

	colno = 1;
	first_time = TRUE;
	while (1) {
		dmapos = bdos(first_time ? SEARCH_FIRST : SEARCH_NEXT,fcb);
		if (dmapos == 255) break;
		first_time = FALSE;
		hackname(tmpfn,(0x80 + dmapos * 32));
		puts(tmpfn);
		for (i = strlen(tmpfn); i < 15; i++) putchar(' ');
		if ((colno += 15) > 65)
		{
			putchar('\n');
			colno =1;
		}
	}
}


hackname(dest,source)
char *dest, *source;
{
	int i,j;

	j = 0;

	for (i = 1; i < 9; i++)
	{
		if (source[i] == ' ') break;
		dest[j++] = source[i];
	}
	if (source[9] != ' ')
		dest[j++] = '.';

	for (i = 9; i < 12; i++)
	{
		if (source[i] == ' ') break;
		dest[j++] = source[i];
	}
	dest[j] = '\0';
	return dest;
}

char *getname(linbuf)		/* get a reasonable filename from user */
char *linbuf;
{
	int i;
	char c;

	while (1)
	{
		gets(linbuf);
		if (!*linbuf)		/* reject null filename */
			goto reject;
		for (i = 0; c = linbuf[i]; i++)
		{
			if (c < ' ' || c > 0x7F)
				goto reject;
		}
		break;
    reject:	puts("\nFilename = ");
		continue;
	}
	return linbuf;
}


ask(s)
char *s;
{

	char c;

again:	printf("%s (y/n)? ", s);
	c = tolower(getchar());
	if(c == 'y') {
		puts("es\n");
		return 1;
	}

	else if(c == 'n')
		puts("o\n");
	else
	{
		printf("  \7Yes or no, please...\n");
		goto again;
	}
	return 0;
}

terminal()	/* terminal mode, no text */
{
	int in;

	putchar('\n');

	while(1)
	{
		if(MOD_RDA)
		{
			putchar(in = MOD_RDATA);
			if (hostflg)
			{
				send(in);
				if (in == '\r')
				{
					send('\n');
					putchar('\n');
				}
			}
		}			
			
		if(kbhit())
		{
			in = getch();
			if (in == SPECIAL)
				return;
			else
				send(in);

			if (hostflg || halfdup)
			{
				putchar(in);
				if (in == '\r')
				{
					putchar('\n');
					if (hostflg)
						send('\n');
				}
			}
		}
	}
}

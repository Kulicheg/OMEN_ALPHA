/*
	RM.C: Generalized file removal utility
	Written by Leor Zolman, 9/86

	Usage:
		rm <list of files>

	Compile & Link:
		cc rm.c
		clink rm wildexp -n
*/

#include <stdio.h>

main(argc,argv)
char **argv;
{
	int i;

	wildexp(&argc, &argv, 1);

	for (i = 1; i < argc; i++)
	{
		puts("Removing "); puts(argv[i]);
		unlink(argv[i]); putchar('\n');
	}
}

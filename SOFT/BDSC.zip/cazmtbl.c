/*
================================================================
CAZMTBL.C -- reserved word and opcode tables for CAZM v0.3a

This file is included during the compilation of CAZM.C.  
Carefully check these tables against the documentation for your 
assembler and edit as necessary.  Three tables are initialized 
here:

	1. reserved words that may appear in the operand field.
	2. opcodes that may require relocation of operands.
	3. relative jump opcodes.

CAZM uses these tables to distinguish between reserved words and
symbols, and to trigger the generation of relocation data in its
output file.
================================================================

Assembler's reserved words that may appear in operand field.  
These include register names (single registers and pairs), jump 
conditions, and arithimetic and logical operators that are 
recognized by your assembler.  Other symbols in the CAZM input 
file  are also added to this table during a CAZM run. */

void initsym()
{
	int i;
	
#if ZILOG

	initptr(sym, "A", "B", "C", "D", "E", "H", "L", "AF", "BC", "DE", 
		"HL", "SP", "IX", "IY", "I", "R", "C", "NC", "M", "P", "PE", 
		"V", "PO", "NV", "Z", "NZ", "NOT", "AND", "XOR", "OR", 
		"HIGH", "LOW", "NUL", "TYPE", "MOD", "SHR", "SHL", "EQ", 
		"NE", "LT", "LE", "GT", "GE", NULL);

#else

	initptr(sym, "A", "B", "C", "D", "E", "H", "L", "PSW", "M", "BC", 
		"DE", "HL", "SP", "IX", "IY", "NOT", "HIGH", "LOW", "NUL", 
		"TYPE", "MOD", "SHR", "SHL", "EQ", "NE", "LT", "LE", "GT", 
		"GE", "AND", "XOR", "OR", NULL);

#endif

	/* set count of table elements */
	for (i = 0; sym[i]; i++)
		;
	syms = i;
}

/* 
---------------------------------------------------------------- 
Opcodes that may need generation of relocation parameters.  
These may use an address in the operand field.  Relative jump 
opcodes are excluded from this table.  They are treated 
separately in initrjump(). */

void initrelop()
{
	int i;

#if ZILOG	/* Zilog mnemonics (normally 4 entries) */

	initptr(relop, DEFWOP, "CALL", "JP", "LD", NULL);

#else		/* extended Intel (normally 36 entries) */

	initptr(relop, DEFWOP, "CALL", "CC", "CM", "CNC", "CNZ", "CP", "CPE", 
		 "CPO", "CZ", "JC", "JM", "JMP", "JNC", "JNZ", "JP", "JPE", 
		 "JPO", "JZ", "LDA", "LHLD", "LXI", "LBCD", "LDED", "LIXD", 
		 "LIYD", "LSPD", "LXIX", "LXIY", "SHLD", "STA", "SBCD", 
		 "SDED", "SIXD", "SIYD", "SSPD", NULL);

#endif

	/* set count of table elements, check for table overflow */
	for (i = 0; relop[i]; i++)
		;
	relops = i;
	if (relops > RELOPMAX)
		abort("* RELOPMAX overflow\n");
}

/* 
---------------------------------------------------------------- 
Relative jump opcodes.  These are treated differently from the 
the other relacatable opcodes. */

initrjump()
{
	int i;

#if ZILOG	/* Zilog mnemonics (normally 2 entries) */

	initptr(rjump, "DJNZ", "JR", NULL);

#else		/* extended Intel (normally 6 entries) */

	initptr(rjump, "DJNZ", "JR", "JRC", "JRNC", "JRNZ", "JRZ", NULL);

#endif

	/* set count of table elements, check for table overflow */
	for (i = 0; rjump[i]; i++)
		;
	rjumps = i;
	if (rjumps > RJUMPMAX)
		abort("* RJUMPMAX overflow\n");
}

/* EOF: CAZMTBL.C */

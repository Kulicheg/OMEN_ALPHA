/*
	Echo command line args
*/

#include <stdio.h>

main(argc,argv)
int argc;
char **argv;
{
	int i;

	printf("Wildexp returns: %d\n", wildexp(&argc, &argv, 1));

	for (i = 1; i < argc; i++)
		printf("arg #%d: \"%s\"\n", i, argv[i]);
}

/*
================================================================
CAZM.C adapted by Jim Chapin (2/91) from:
	CASM.C v1.6 written by Leor Zolman (5/86),
	ZCASM.C v1.3 written by Brian Waldron (2/84), and
	ZCASM.C v1.5 updated by Lindsay Haisley (11/86)

--> CONFIGURE FOR YOUR ASSEMBLER WITH CAZM.H BEFORE COMPILING

CAZM is intended as a replacement for CASM to allow use of the 
full Z80 instruction set.  It may be configured (see CAZM.H) 
for either Zilog or Z80.LIB (extended Intel) mnemonics for use 
with SLR Systems' Z80ASM or SLRMAC assemblers. See the CASM 
Appendix in the BDS C User's Guide, CAZM.DOC, and CAZM.UPD for 
more information.

================================================================
*/

#include <stdio.h>
#include "cazm.h"
#include "cazmtbl.c"

#define TITLE "BDS C Z80 Assembly Language Preprocessor"
#define VERSION "0.3a (3/92)"

#if ZILOG
#define IOFORM "Zilog"
#else
#define IOFORM "Extended Intel"
#endif

#define DIRENT	8		/* max # of chars in CRL dir entry */
#define DIRSIZE	512		/* max # of bytes in CRL directory */
#define TPALOC	0x100		/* base of TPA in your system */
#define BELL	'\07'		/* ring bell for error messages */
#define SPACES	"          "	/* spaces for clean console messages */

/* 
----------------------------------------------------------------
Open main input file, open output file, initialize needed globals
and process the file: */

main(argc, argv)
int argc;
char **argv;
{
	char c, *inpnam, *outnam, outfile[30];
	int i, j, k;

	printf("%s\n v%s for %s mnemonics\n", TITLE, VERSION, IOFORM);

	initsym();	/* initialize sym with reserved words */
	initrelop();	/* initialize relop with relocatable ops */
	initrjump();	/* initialize rjump with relative jump ops */

	funcs = 0;		/* haven't seen any functions yet */
	infunc = FALSE;		/* not currently processing a function */
	errf = FALSE;		/* no errors yet */
	comments = verbose = debug = FALSE; /* no options yet */
	inpnam = outnam = NULL;	/* haven't seen any names yet */
	nestlev = 0;		/* at top level to start with */
	
	while (--argc) {
		++argv;		/* bump to next arg text */
		if (**argv == '-') {
			switch (c = argv[0][1]) {
				case 'C':
					comments = TRUE;
					break;
				case 'V':
					verbose = TRUE;
					break;
				case 'O':
					if (argv[0][2])
						outnam = &argv[0][2];
					else if (--argc)
						outnam = *++argv;
					else goto usage;
					break;
				case 'D':
					debug = TRUE;
					break;
				default: goto usage;
			}
		}
		else inpnam = *argv;
	}

	if (!inpnam) {
usage:		printf("Usage:\tcazm [-c] [-v] [-o <name>] <filename>");
		printf("\n\t-C: save source Comments in output");
		printf("\n\t-V: Verbose output");
		printf("\n\t-O <name>: name Output file <name>%s\n", ASMEXT);
		exit();
	}

	/* set up filenames with proper extensions: */
	for (i = 0; (c = inpnam[i]) && c != '.'; i++)
		infile[0][i] = c;
	infile[0][i] = '\0';

	strcpy(outfile, outnam ? outnam : infile[0]);
	strcat(infile[0], CAZMEXT);	/* input filename */
	curfile = infile[0];		/* current filename pointer */

	if ((infp = fopen(curfile, "r")) == NULL) {
		printf("can't open %s\n", curfile);
		exit();
	}
	fp[0] = infp;
	if (debug)
		printf("infp = %04x\n", infp);
	if (!hasdot(outfile))
		strcat(outfile, ASMEXT);	/* output filename */
	if ((outfp = fopen(outfile, "w")) == NULL) {
		printf("can't create %s\n", outfile);
		exit();
	}
		/* begin writing output file */
	foutf(outfp, "\nTPALOC\t\tEQU\t%04xH\n", TPALOC);
	foutf(outfp, "\nSYS_EXTFLAG\t%s\t0", DEFLOP);
	foutf(outfp, "\nSYS_EXTADDR\t%s\t0000H", DEFLOP);
	foutf(outfp, "\nSYS_EXTSIZE\t%s\t0000H", DEFLOP);
	foutf(outfp, "\n\t\tORG\tTPALOC + 0205H\n\n");

	lino = 1;			/* initialize line count */

	while (get_line()) {		/* main loop */
		if (kbhit() && getchar() == CONTROL_C)
			abort("* Aborted...\n");
		process_line();		/* process lines till EOF */
		lino++;
	}

	if (infunc)			/* if ends inside a function, error */
		abort("* EOF: last function not terminated\n");

	if (errf) {
		printf("correct errors, try again...\n");
		unlink(outfile);
		if (*SUBFILE) 
			unlink(SUBFILE);
	} else {
		/* end of functions */
		foutf(outfp, "\nEND_CRL\t\tEQU\t$ - TPALOC\n");
		putdir();	/* output CRL directory */
		foutf(outfp, "\t\tEND\n%c", CPMEOF); /* end of ASM file */
		fclose(infp);	/* close input file */
		fclose(outfp);	/* close output file */
		printf("%s is ready to be assembled.\n", outfile);
	}
} /* end of main() */

/* 
---------------------------------------------------------------- 
Get a line of text from input stream, and process "include" ops 
on the fly: */

int get_line()
{
	FLAG quoted, dquoted;
	char fspec[30], savlino[NESTMAX];
	int i;

top:	if (finf(linebuf, MAXLINE, infp) == NULL) {	/* on EOF: */
		if (nestlev) {			/* in "include" file? */
			fclose(infp);		/* yes; return to previous; */
			infp = fp[--nestlev];	/* restore buffer ptr */
			curfile = infile[nestlev];	/* and filename */
			lino = savlino[nestlev] + 1;	/* and line no. */
			return (get_line());
		} else return (NULL);
	}

	if (!comments) {	/* strip commments, default */
		quoted = FALSE;
		dquoted = FALSE;
		for (i = 0; linebuf[i]; i++) {
			if (linebuf[i] == ';' && !quoted && !dquoted) {
				while (i && isspace(linebuf[i-1]))
					i--;
				if (!i) {
					lino++;
					goto top;
				}
				strcpy(&linebuf[i], "\n");
				break;
			}
			if (linebuf[i] == '\'' && !dquoted)
				quoted ^= 1;
			if (linebuf[i] == '"' && !quoted)
				dquoted ^= 1;
		}
	}
	parse_line();			/* not EOF. Parse line */
	if (streq(op, "INCLUDE")	/* check for file inclusion */
		 || streq(op, "MACLIB")) {
		if (nestlev == NESTMAX)      /* if nested to the max, error */
			abort("* NESTMAX overflow\n");
		if (!argp)
			abort("* no filename for MACLIB/INCLUDE\n");
					/* set up for inclusion */
		savlino[nestlev++] = lino;
		for (i = 0; !isspace(argp[i]); i++)	/* put null after */
			;				/* filename */
		argp[i] = '\0';

#if INTEL
#if SLRMAC		/* special case for SLRMAC to activate
			   Z80 extensions without macro file */
		if (streq(op, "MACLIB") && streq(argp, "Z80")) {
			nestlev--;
			return (TRUE);
		}
#endif
#endif
		*fspec = '\0';
		if (*argp == '<') {	/* look for magic delimiters */
			strcpy(fspec, DEFDIR);
			strcat(fspec, argp + 1);
			if (fspec[i = strlen(fspec) - 1] == '>')
				fspec[i] = '\0';
		} else if (*argp == '"') {
			strcpy(fspec, argp + 1);
			if (fspec[i = strlen(fspec) - 1] == '"')
				fspec[i] = '\0';
		} else
			strcpy(fspec, argp);

		while ((infp = fopen(fspec, "r")) == NULL) {
			if (hasdot(fspec))
				abort("* can't find %s\n", fspec);
			else
				strcat(fspec, LIBEXT);
		}
		printf("reading %s,%s\r", fspec, SPACES);
		strcpy(&infile[nestlev], fspec);
		curfile = infile[nestlev];
		fp[nestlev] = infp;
		lino = 1;
		return (get_line());
	}
	return (TRUE);
} /* end of get_line() */

/*
----------------------------------------------------------------
Parse input line: */

void parse_line()
{
	FLAG quoted, dquoted;
	char *cp;
	int i;
	
	label = op = argp = NULL;
	args = 0;

		/* copy linebuf to parsbuf while converting to uppercase */
	for (i = 0; linebuf[i]; i++)
	     parsbuf[i] = toupper(linebuf[i]);
	parsbuf[i] = '\0';

	cp = parsbuf;

	if (!*cp)
		return;		/* ignore null lines */
	if (!isspace(*cp)) {
		if (*cp == ';')
			return;		/* totally ignore comment lines */
		label = cp;		/* set pointer to label */
		while (isidchr(*cp))	/* pass over label identifier */
			cp++;
		*cp++ = '\0';	/* place null after identifier */
	}
		/* find and process op */
	while (isspace(*cp))
		cp++;
	if (!*cp || *cp == ';')
		return;
	op = cp;		/* set pointer to op mnemonic */
	while (isalpha(*cp))
		cp++;  		/* skip over the op */
	if (*cp)
		*cp++ = '\0';	/* place null after the op */

		/* now find and process arguments */
	while (isspace(*cp))
		cp++;
	if (!*cp || *cp == ';')
		return;
	argp = cp; 		/* set pointer to arg list */

		/* create vector of pointers to all
		   args that may be relocatable: */
	quoted = FALSE;		/* no single (') quoted string yet */
	dquoted = FALSE;	/* no double (") quoted string yet */
	for (args = 0; args < ARGMAX; ) {
		while (!isidstrt(*cp)) {
			if (!*cp || *cp == ';')
				return;
			if (*cp == '\'' && !dquoted)
				quoted ^= 1;
			if (*cp == '"' && !quoted)
				dquoted ^= 1;
			cp++;
		}
		if (isidchr(*(cp - 1))) {
			cp++;
			continue;
		}
		if (!quoted && !dquoted) {
			arg[args++] = cp;			
			while (isidchr(*cp))
				cp++;
			if (*cp)	/* more chars? */
				*cp++ = '\0';
		} else
			cp++;
	}
	abort("* ARGMAX overflow\n");
} /* end of parse_line */

/*
----------------------------------------------------------------
Process input line: */

void process_line()
{
	char *cp, *xf, tempbuf[MAXLINE];
	int i, j;

	if (op) {	/* check for definitions of global data that will be
			   exempt from relocation when encountered in the
			   argument field of assembly instructions: */

		if (streq(op, "EQU") || streq(op, DEFLOP)
		    || (!infunc && (streq(op, DEFBOP)
				    || streq(op, DEFCOP)
				    || streq(op, DEFSOP)
				    || streq(op, DEFWOP)
				    || streq(op, DEFZOP)))) {
			foutf(outfp, linebuf);
			cp = sbrk2(strlen(label) + 1);
			strcpy(cp, label);
			sym[syms++] = cp;
			if (syms >= SYMMAX)
				abort("* SYMMAX overflow\n");
			return;
		}

		if (streq(op, "EXTERNAL")) {
			if (!infunc)
				abort("* externals outside function\n");
			if (pastxfs)
				error("externals not together\n");
			for (i = 0; i < args; i++) {
				xfunc[xfuncs++] = textp;
				strcpy(textp, arg[i]);
				inctextp(arg[i]);
			}
			if (xfuncs >= XFMAX)
				abort("* XFMAX overflow\n");
			return;
		}

		if (streq(op, "FUNCTION")) {
			if (infunc) {
				abort("* FUNCTION op inside function\n");
			}
			if (!args)
				abort("* name required for FUNCTION op\n");

			curfunc = sbrk2(strlen(arg[0]) + 1);
			func[funcs++] = curfunc;
			strcpy(curfunc, arg[0]);

			if (!debug)
			    printf("processing %s(),%s\r", curfunc, SPACES);

			infunc = TRUE;
			textp = textbuf;
			labels = 0;
			xfuncs = 0;
			pastxfs = FALSE;

			if (verbose)
				foutf(outfp, "\n\n; ----- %s\n", curfunc);
			foutf(outfp, "%s_BEG\tEQU\t$ - TPALOC\n", curfunc);
			return;
		}

		if (streq(op, "ENDFUNC") || streq(op, "ENDFUNCTION")) {
			if (!infunc)
				abort("* ENDFUNCTION op outside function\n");
			if (!pastxfs)
				flushxfs();   /* flush needed function list */
			foutf(outfp, "%s_END\tEQU\t$\n", curfunc);
			doreloc();	     /* flush relocation parameters */
				/* detect undefined labels */
			for (i = 0; i < labels; i++)
			  if (!lbl[i].defined) {
			    error("label %s in %s() is undefined\n",
				   lbl[i].lblnam, curfunc);
			    errf = TRUE;
			  }
			infunc = FALSE;
			return;
		}
	}

	/* No special pseudo-ops, so now process line as assembly code: */

	if (streq(op, "END"))
		return;		/* don't allow "end" yet */

	if (!infunc || (!label && !op)) {	/* if nothing interesting */
		foutf(outfp, linebuf);		/* on line, ignore it */
		return;
	}
	if (!pastxfs)		/* if haven't flushed needed */
		flushxfs();	/* function list yet, do it */

		/* check for possible label */
	if (label) {
		foutf(outfp, "%s?%s\tEQU\t$ - %s_STRT\n",
			curfunc, label, curfunc);
		for (i = 0; linebuf[i]; i++)
			if (isspace(linebuf[i]) || linebuf[i] == ':')
				break;
			else
				linebuf[i] = ' ';
		if (linebuf[i] == ':')
			linebuf[i] = ' ';
		for (i = 0; i < labels; i++)	  /* check label table */
				/* if found, check for redefinition */
			if (streq(label, lbl[i].lblnam)) {
				if (lbl[i].defined)
				    error("label %s re-defined\n",
					  lbl[i].lblnam);
				else
					lbl[i].defined = TRUE;
				goto out;
			}
		lbl[i].lblnam = textp;	/* add new entry to */
		lbl[i].defined = TRUE;	/* label list */
		strcpy(textp, label);
		inctextp(label);
		if (labels++ >= LBLMAX)
			abort("* LBLMAX overflow\n");
	}
out:	if (!op) {
		foutf(outfp, linebuf);	/* if label only, all done */
		return;
	}
	if (!intable(op, relop, relops)		/* if not relocatable, */
	    && !intable(op, rjump, rjumps)) {	/* and not rel jump */
		foutf(outfp, linebuf);		/* then we're done */
		return;
	}
	if (args && infunc) {
	    for (i = 0; i < args; i++) {
		if (xf = intable(arg[i], xfunc, xfuncs))
			sprintf(workbuf, "%s.%s - %s_STRT",
				curfunc, xf, curfunc);
		else if (intable(arg[i], sym, syms))
			continue;
		else {
			sprintf(workbuf, "%s?%s", curfunc, arg[i]);
			for (j = 0; j < labels; j++)
				if (streq(arg[i], lbl[j].lblnam))
					goto out2;
			lbl[j].lblnam = textp;	/* add entry to */
			lbl[j].defined = FALSE;	/*  label list */
			strcpy(textp, arg[i]);
			inctextp(textp);
			labels++;
		}		   
out2:		if (intable(op, rjump, rjumps)) {	/* nullify offset */
			sprintf(tempbuf, " + %s_STRT", curfunc);
			strcat(workbuf, tempbuf);
		}
			/* replace args in source with cazm-style args */
		j = arg[i] - parsbuf + strlen(arg[i]);	/* where arg ends */
		strcpy(tempbuf, linebuf + j);	  /* save rest of line */
		linebuf[arg[i] - parsbuf] = '\0'; /* truncate original line */
		strcat(workbuf, tempbuf);	  /* add saved line end */
		strcat(linebuf, workbuf);	  /* line now complete */

		if (streq(op, DEFWOP)) {
			foutf(outfp, "%s?%03d\tEQU\t$ - %s_STRT\n",
				curfunc, relocs++, curfunc);
			if (args > 1)
			    error("%s: more than one relocatable value\n",
				   DEFWOP);
		} else if (!intable(op, rjump, rjumps)) {
			foutf(outfp, linebuf);
			sprintf(linebuf, "%s?%03d\tEQU\t$ - 2 - %s_STRT\n",
				curfunc, relocs++, curfunc);
		}
		break;
	    } /* end for (...) */
	} /* end if (...) */
	foutf(outfp, linebuf);
} /* end process_line() */

/*
----------------------------------------------------------------
Output list of external functions: */

void flushxfs()
{
	int i, j, len;

	pastxfs = TRUE;
	relocs = 0;

	if (verbose)
		foutf(outfp, "\n\n; External functions:\n");

	for (i = 0; i < xfuncs; i++) {
		len = strlen(xfunc[i]);
		len = len < DIRENT ? len : DIRENT;
		for (j = 0; j < len; j++)
			workbuf[j] = xfunc[i][j];
		workbuf[j] = '\0';
		foutf(outfp, "\t\t%s\t'%s'\n", DEFCOP, workbuf);
	}

	foutf(outfp, "\t\t%s\t0\n", DEFBOP);

	if (verbose)
		foutf(outfp, "\n; Length of body:\n");

	foutf(outfp, "\t\t%s\t%s_END - $ - 2\n", DEFWOP, curfunc);

	if (verbose)
		foutf(outfp, "\n; Function body:\n");

	foutf(outfp, "%s_STRT\tEQU\t$\n", curfunc);
	if (xfuncs) {
		foutf(outfp, "%s?%03d\tEQU\t$ + 1 - %s_STRT\n",
			curfunc, relocs++, curfunc);
		foutf(outfp, "\t\t%s\t%s_CODE - %s_STRT\n",
			JUMPOP, curfunc, curfunc);
	}
	foutf(outfp, "%s.%s\tEQU\t%s_STRT\n",
		curfunc, curfunc, curfunc);
	for (i = 0; i < xfuncs; i++) {
		foutf(outfp, "%s.%s\t%s\t0\n",
			curfunc, xfunc[i], JUMPOP);
	}
	foutf(outfp, "\n%s_CODE\tEQU\t$\n", curfunc);
}

/*
----------------------------------------------------------------
Output relocation parameters: */

void doreloc()
{
	int i;

	if(verbose)
		foutf(outfp, "\n; Relocation parameters:\n");
	foutf(outfp, "\t\t%s\t%d\n", DEFWOP, relocs);
	for(i = 0; i < relocs; i++)
		foutf(outfp, "\t\t%s\t%s?%03d\n", DEFWOP, curfunc, i);
	foutf(outfp, "\n");
}

/*
----------------------------------------------------------------
Output CRL directory: */

void putdir()
{
	int i, j, len;
	int bytes;

	bytes = 0;

	foutf(outfp, "\n\t\tORG\tTPALOC\n\n; Directory:\n");
	for (i = 0; i < funcs; i++) {
		len = strlen(func[i]);
		len = len < DIRENT ? len : DIRENT;
		for (j = 0; j < len; j++)
			workbuf[j] = func[i][j];
		workbuf[j] = '\0';
		foutf(outfp, "\t\t%s\t'%s'\n", DEFCOP, workbuf);
		foutf(outfp, "\t\t%s\t%s_BEG\n", DEFWOP, func[i]);
		bytes += (len + 2);
	}
	foutf(outfp, "\t\t%s\t80H\n\t\t%s\tEND_CRL\n", DEFBOP, DEFWOP);

	bytes += 3;
	if (bytes > DIRSIZE)
		abort("* directory exceeds %d bytes\n", DIRSIZE);

	foutf(outfp, "\n\n; External information:\n");
	foutf(outfp, "\t\tORG\tTPALOC + 0200H\n");
	foutf(outfp, "\t\tIF\tSYS_EXTFLAG NE 0\n");
	foutf(outfp, "\t\t%s\t0BDH\n", DEFBOP);
	foutf(outfp, "\t\tELSE\n");
	foutf(outfp, "\t\t%s\t0\n", DEFBOP);
	foutf(outfp, "\t\tENDIF\n");
	foutf(outfp, "\t\t%s\tSYS_EXTADDR\n", DEFWOP);
	foutf(outfp, "\t\t%s\tSYS_EXTSIZE\n", DEFWOP);

}

/*
----------------------------------------------------------------
Return true if c is legal character in identifier: */

int isidchr(c)
char c;
{	
	return (isalpha(c)
		|| isdigit(c)
		|| c == '$'
		|| c == '%'
		|| c == '_'
		|| c == '.'
		|| c == '?'
		|| c == '@');
}

/*
----------------------------------------------------------------
Return true if c is legal as first character of identifier: */

int isidstrt(c)
char c;
{
	return (isidchr(c) && !isdigit(c));
}

/*
----------------------------------------------------------------
Return true if the two strings are equal: */

int streq(s1, s2)
char *s1, *s2;
{
	if (*s1 != *s2)
		return (FALSE);		/* special case for speed */
	while (*s1)
		if (*s1++ != *s2++)
			return (FALSE);
	return (*s2 ? FALSE : TRUE);	/* is s2 longer? */
}

/*
----------------------------------------------------------------
Allocate storage and check for out of space condition: */

int sbrk2(n)
int n;
{
	int i;
	if ((i = sbrk(n)) == ERROR)
		abort("* out of storage allocation space\n");
	return (i);
}

/*
----------------------------------------------------------------
Increment textp by size of given string + 1: */

void inctextp(str)
char *str;
{
	textp += strlen(str) + 1;
	if (textp >= textbuf + (TEXTMAX - 8))
	    abort("* TEXTMAX overflow\n");
}

/*
----------------------------------------------------------------
Generalized table lookup function: 

s	= string to compare with table elements 
table	= name of table
tsize	= number of table elements 

*/

char *intable(s, table, tsize)
char **table, *s;
int tsize;
{
	int i;
	
	for (i = 0; i < tsize; i++)
		if (streq(s, table[i]))
			return (table[i]);
	return (NULL);
}

/*
----------------------------------------------------------------
Return true if given string contains a period: */

int hasdot(str)
char *str;
{
	while (*str)
		if (*str++ == '.')
			return (TRUE);
	return (FALSE);
}

/*
----------------------------------------------------------------
Get a line from current input file: */

char *finf(buf, maxlen, fp)
char *buf;
int maxlen;
FILE *fp;
{
	char *s;
	s = fgets(buf, maxlen, fp);
	if (debug)
		printf("--CAZM input:\n%s--CAZM output:\n", buf);
	return (s);
}

/*
----------------------------------------------------------------
Output line: */

void foutf(fp, format, s1, s2, s3)
FILE *fp;
char *format, *s1, *s2, *s3;
{
	if (debug)
		printf(format, s1, s2, s3);
	else
		if (fprintf(fp, format, s1, s2, s3) == ERROR)
			abort("* out of disk space\n");
}

/*
----------------------------------------------------------------
Display error message, close files, quit: */

void abort(format, s1, s2)
char *format, *s1, *s2;
{
	int i;

	error(format, s1, s2);
	for (i = nestlev; i >= 0; i--)
		fclose(fp[i]);
	if (*SUBFILE)
		unlink(SUBFILE);
	exit(-1);
}

/*
----------------------------------------------------------------
Display error message, but keep going: */

void error(format, s1, s2)
char *format, *s1, *s2;
{
	printf("\n%c%s: %d: ", BELL, curfile, lino);
	printf(format, s1, s2);
	errf = TRUE;
}

/*
----------------------------------------------------------------
EOF: CAZM.C */

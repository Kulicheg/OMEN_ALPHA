/*
	This is a test of a C program running under the new
	Z-systems run-time environment
*/

#include <stdio.h>

struct ndr_entry {
	char drive;
	char user;
	char name[8];
	char passwd[8];
} *ndrep;


main()
{
	char *zenvp;
	int *zwp;
	int *ndrp;
	int zwpval;
	int i;

	zenvp = zenv();

	printf("\n\n");
	printf("Hello, Jay!\n");
	printf("topofmem() = %x, endext() = %x\n",
		topofmem(), endext());
	printf("zenvp = %04x\n",zenvp);

	zwp = zenvp + 0x1b;
	zwpval = *zwp;
	
	printf("reflexive pointer value = %04x\n", zwpval);

	printf("let's check out the NDR:\n");
	zwp = zenvp + 0x0015;
	ndrp = *zwp;
	printf("NDR address = %04x\n",ndrp);

	ndrep = ndrp;

	for (i = 0; ndrep->drive; i++, ndrep++)	/* while drive byte not 0... */
	{
		printf("\nNDR entry #%d:\n", i+1);
		printf("Drive: %c, User: %d, Name: %s, ",
			ndrep->drive+'@', ndrep->user, nstr(ndrep->name));
		printf(" passwd = %s\n", nstr(ndrep->passwd));
	}
}

/*
	Given a pointer to an NDR name string, convert to a
	null terminated string and return a pointer to the new string:
*/

char *nstr(zstr)
char *zstr;
{
	int i;
	char *statstr, c, *sptr;

	sptr = statstr = "This is a dummy";	/* fake 'static' */

	for (i = 0; i < 8; i++)
		if ((c = zstr[i]) == ' ')
			break;
		else
			*sptr++ = c;

	*sptr = '\0';
	return statstr;
}
	
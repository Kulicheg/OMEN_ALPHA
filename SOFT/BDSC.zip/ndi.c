/*
	NDI.C

	Find simple differences between two binary or text files.
	Written by Leor Zolman. This command is useful for quick comparisons,
	as to determine whether two files are identical, or else to find the
	first area of divergence.

	The addresses printed for binary files assumes they are being examined
	using DDT or SID (i.e., offset by 100h from the start of the file.)

	Usage: 
		ndi <file1> <file2> [-a]
	  or	ndi <file1> <du:> 	(shorthand for same filename in
					 different directory)

	Compile by:
		cc ndi.c -e2300 -o
		clink ndi -n
*/

#include <stdio.h>

#define SECSIZE		128
#define BUFSECTS	64
#define BUFSIZE (BUFSECTS * SECSIZE)
#define CTRL_Z		('Z' - 0x40)

int i, j;
unsigned count, errloc;
unsigned lineno;

char nam2[20];
char perfect;
int ascii_flag;

int fd1, fd2;
char fbuf1[BUFSIZE], fbuf2[BUFSIZE];
int blocks1, blocks2;

unsigned last_both;	/* greatest # of chars read from BOTH files */
char c1, c2;

main(argc,argv)
char **argv;
{
	if (argc < 3)
	{
	   printf("Usage:\ndi file1 file2 [-a]\n");
	   printf("or:\ndi file1 <du:> [-a]\n");
	   exit();
	}

	if ((fd1 = open(argv[1], 0)) == ERROR)
	{
		printf("Can't open %s\n",argv[1]);
		exit();
	}

	strcpy(nam2,argv[2]);		/* construct second filename */
	if ((j = nam2[strlen(nam2)-1]) == ':')
	{
		for (i = strlen(argv[1])-1; i >= 0; i--)
			if (argv[1][i] == ':')
				break;
		strcat(nam2, &argv[1][i+1]);
	}

	if ((fd2 = open(nam2, 0)) == ERROR)
	{
		printf("Can't open %s\n",nam2);
		exit();
	}

	if (argc == 4 && argv[3][1] == 'A')
		ascii_flag = 1;

	printf("Comparing %s to %s (%s mode):\n",argv[1],nam2,
			ascii_flag ? "ASCII" : "Binary");

	lineno = 1;
	perfect = TRUE;
	blocks1 = blocks2 = 0;

	for (count = 0x100 ; ; count += last_both)
	{
		if (kbhit())		/* flow control */
			getchar();
	
		blocks1 = read(fd1, fbuf1, BUFSECTS);
		blocks2 = read(fd2, fbuf2, BUFSECTS);

		if (blocks1 <= 0)
		{			/* EOF file1? */
			if (blocks2 == 0)
			{	/*1st ended. did 2nd?*/
		perf:		if (perfect)
					printf("Perfect match!\n");   /* yes */
				break;
			}
			else
			{			       /* no */
				printf("%s ends at %04x",argv[1],count);
				if (ascii_flag)
					printf(" [line %d]",lineno);
				printf(", but %s goes on...\n",nam2);
				break;
			}
		}
		else if (blocks2 <= 0)	/* 1st file didn't end */
		{			/* did 2nd? if so, ...*/
			printf("%s ends at %04x",nam2,count);
			if (ascii_flag)
				printf(" [line %d]",lineno);
			printf(", but %s goes on...\n",argv[1]);
			break;
		}

				 /* compare max bytes common to both: */
		last_both = min(blocks1, blocks2) * SECSIZE;
		if (memcmp(fbuf1, fbuf2, last_both))
		{			/* entire block matches */
			if (ascii_flag)	/* update ascii line count */
				for (i = 0; i < last_both; i++)
					if (fbuf1[i] == '\n')
						lineno++;
			continue;
		}
					
				/* blocks have a mismatch */
		for (i = 0; i < last_both; i++)
		{
			c1 = fbuf1[i];
			c2 = fbuf2[i];

			if (ascii_flag)
			{
				if (c1 == '\n')
					lineno++;
				if (c1 == CTRL_Z && c2 == CTRL_Z)
				{
					if (perfect)
						printf("Perfect match!\n");
					goto done;
				}
			}

			if (c1 == c2)
				continue;

			printf("Mismatch at location %04x", count + i);
			if (ascii_flag)
				printf(" [line %d]",lineno);
			printf(":   %s: ", argv[1]);
			if (ascii_flag) 
			{
				printf(" '%c', %s: '%c'\n", c1, nam2, c2);
				if (c1 == CTRL_Z)
				{
					printf("%s: END-OF-FILE!\n", argv[1]);
					goto done;
				}
				if (c2 == CTRL_Z)
				{
					printf("%s: END-OF-FILE!\n", nam2);
					goto done;
				}
			}
			else
				printf(" %02x, %s: %02x\n", c1, nam2, c2);

			perfect = FALSE;
		}
	}

done:
	fclose(fbuf1);
	fclose(fbuf2);
}

/*  COPYRIGHT 1983 BY ROBERT WARD -- ALL RIGHTS RESERVED */
#include <stdio.h>
#include "mconfig.h"

#define CONSOLE 1
#define PRINTER 2
#define FPLEN PREC/2+1
#define WID PREC-1

main()
{
char obuf[120];
char testnum[PREC/2 +1], buf[256];
char num1[PREC/2+1], out[PREC/2+1];
char out2[FPLEN],out3[FPLEN],out4[FPLEN];
char out5[FPLEN],out6[FPLEN];
int i;
int k;

do{
	do{
	   fprintf(CONSOLE, "\n\nEnter 2 floating point numbers: ");
	   k = scanf("%f %f",testnum,num1);
	}  while (k != 2);

        do {
	   fprintf(CONSOLE, "\n%40s","enter an integer ");
	   i = scanf("%d",&k);
	} while(i!=1);

	fprintf(CONSOLE,"\n%20s = %20.13e","op1",testnum);
	fprintf(CONSOLE,"\n%20s = %20.13e","op2",num1);
	fprintf(CONSOLE,"\n%20s = %20d","k",k);
	fprintf(CONSOLE,"\n%20s = %20.13e","zfl(op1,k)",
	        zfl(assign(out5,testnum),k));
	fprintf(CONSOLE,"\n%20s = %20.13e",
		"round(op1,k)",frnd(testnum,k,out5));
	fprintf(CONSOLE,"\n%20s = %20.13e",
		"neg(op1)",fneg(testnum,out5));
	fprintf(CONSOLE,"\n%20s = %20.13e",
		"fpabs(op1)",fpabs(testnum,out5));
	fprintf(CONSOLE,"\n%20s = %20.13e",
		"itof(k)", itof(out5,k));
	fprintf(CONSOLE, "\n%20s = %20.13e",
		"ftrunc(op1)",ftrunc(testnum,out5));
	fprintf(CONSOLE,"\n%20s = %d",
		"fpcmp returns",fpcmp(testnum,num1));
	fprintf(CONSOLE,"\n%20s = %d",
		"fscmp returns",fscmp(testnum,num1));
	fprintf(CONSOLE,"\n%20s = %d",
		"ftoi(op1)",ftoi(testnum));
	fprintf(CONSOLE, "\n%20s = %20.13e",
		"scale(k, op1)",scale(testnum,k,out5));
	fstat(); /*clear status flags*/
	fpadd(testnum,num1,out);
	fprintf(CONSOLE,"\n%20s = %20.13e %s",
		"sum",out,errm());
	fpsub(testnum,num1,out2);
	fprintf(CONSOLE,"\n%20s = %20.13e %s",
		"difference",out2,errm());
	fpmult(testnum,num1,out3);
	fprintf(CONSOLE,"\n%20s = %20.13e %s",
		"product",out3,errm());
	fpdiv(testnum,num1,out4);
	fprintf(CONSOLE,"\n%20s = %20.13e %s",
		"quotient",out4,errm());
	} while (TRUE);
}


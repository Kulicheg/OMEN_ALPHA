#include <stdio.h>
#include "mconfig.h"

#define MAXLINE 255  /*longest string atof will process */


_spr(fmt,putcf,arg1)
int (*putcf)();
char **fmt;
{
	char _uspr(), c, base, *format, ljflag, prefill, *wptr;
        char xchr;      /* the character to be used in e formats */
	char wbuf[PREC+7];	/* 20 is enough for all but %s */
	char temp[PREC/2+1];  /*for rounded fp number */
	int length, *args, width, precision, pwid,exp;
	char *tpnt;
        int i, trunc,t;
	format = *fmt++;    /* fmt first points to the format string	*/
	args = fmt;	    /* now fmt points to the first arg value	*/

	while (c = *format++)
	  if (c == '%') {
	    wptr = wbuf;
	    precision = 32767;
            trunc = 0;
	    width = ljflag = 0;
	    prefill = ' ';
            xchr = 'e';

	    if (*format == '-') {
		    format++;
		    ljflag=1;
	     }


	    if (*format == '0') prefill = '0';

	    if (*format == '*'){
	       format++;
	       precision = *args++;
	       }

	    if (isdigit(*format)) width = _gv2(&format);

	    if (*format == '.') {
		    format++;
		    if (*format == '*'){
		       format++;
		       precision = *args++;
		       }
		    else
                       if (isdigit(*format)) precision = _gv2(&format);
                    }
            if (*format == 'l') format++; /*no longs here */
	    switch(c=*format++) {
		case 's':
			   wptr = *args++;
			   length = strlen(wptr);
			   if (precision < length) length=precision;
			   width -= length;
			   goto pad7;

		case 'c':  *wptr++ = *args++;
			   width--;
			   goto pad;

		case 'd':  if (*args < 0) {
				*wptr++ = '-';
				*args = -*args;
				width--;
			    }
		case 'u':  base = 10; goto val;

		case 'b':  base = 2; goto val;

		case 'x':  base = 16; goto val;

		case 'o':  base = 8;

		val:       width -= _uspr(&wptr,*args++,base);
			   goto pad;

                case 'G':  xchr = 'E';
                case 'g':  trunc = TRUE;
                           prefill = ' ';
                           exp = mag(*args);
                           if (precision == 32767) precision = 6;
                           if ((exp < -4) || (exp > precision)) goto doe;
                           else goto dof;

                case 'E':  xchr = 'E';
                case 'e':  if (precision == 32767) precision = 6;
		doe:
                           fprnd(*args++,temp,precision);
			   /*
			    replace this line with
			    assign(temp,*args++)
			    to get rid of rounding on output
			    */
			   _fpand(temp,wbuf);
			   _fpxnd(temp[PREC/2]>>1,wbuf+PREC+1,xchr);
                           if (trunc){
                              wptr=wbuf+1;
                              for (i=0; i<PREC-1; i++) {
                                 if (*wptr++ != '0') precision = i;
                                 }
                              }
			   pwid=width - ((precision)?precision+6:5)
			        -((*wbuf)?1:0);
			   pwid=(pwid < 0)? 0:pwid;
                           if(*wbuf){
                              if (ERROR==(*putcf)('-',arg1))
                                 return ERROR;
                              }
			   if (!ljflag){
                               while (pwid--){
 	                          if (ERROR == (*putcf)(prefill,arg1))
 	                             return ERROR;
 	                          }
 	                       }
 	                   if (ERROR==_fpespr(putcf,arg1,wbuf,precision))
 	                      return ERROR;
                           goto fpad;

                case 'f':  if (precision == 32767) precision = 6;
                dof:
			   exp = mag(*args);
                           fprnd(*args++,temp,precision+exp);
			   /* replace the above two lines with
			       assign(temp,*args++)
			      to get rid of rounding on output
			   */
                           _fpand(temp,wbuf);
                           exp = mag(temp); /*can change in round */
                           if (trunc){
                              if ((t=exp+precision) > (PREC -1))
                                 precision = (t=(PREC-1)) - exp;
                              else if (t < 0) precision = 0;
                              t+=1;
                              while ((precision) && (wbuf[t]=='0')){
                                 precision--;
                                 if ((--t)<0) precision = 0;
                                 }
                              }
                           pwid = width
                                  -((precision)?precision+1:0)
                                  -((*wbuf)?1:0);
                           pwid -= ((exp < 0)? 0: exp + 1);
                           if (!(pwid<width) && !precision) {
                              pwid-=2;
                              precision = 1;
                              }
                           pwid = (pwid < 0)? 0: pwid;
                           if (*wbuf)
                              if (ERROR==(*putcf)('-',arg1))
                                 return ERROR;
                           if (!ljflag){
                              while (pwid--){
                                 if (ERROR == (*putcf)(prefill,arg1))
                                    return ERROR;
                                 }
                              }
                           if (ERROR==
                                _fpfspr(putcf,arg1,wbuf,exp,precision))
                              return ERROR;
                fpad:      if (ljflag){
                              while(pwid--){
                                 if (ERROR == (*putcf)(' ',arg1))
                                    return ERROR;
                                 }
                              }
			   break;
			   
		pad:
			   *wptr = '\0';
			   length = strlen(wptr = wbuf);
		pad7:		/* don't modify the string at wptr */
			   if (!ljflag)
				while (width-- > 0)
					if ((*putcf)(prefill,arg1)
						== ERROR) return ERROR;;

			   while (length--)
				if ((*putcf)(*wptr++,arg1) == ERROR) 
					return ERROR;

			   if (ljflag)
				while (width-- > 0)
					if ((*putcf)(' ',arg1) == ERROR)
						return ERROR;
			   break;

		case NULL:
			   return OK;

		default:   if ((*putcf)(c,arg1) == ERROR) return ERROR;
	     }
	  }
	  else if ((*putcf)(c,arg1) == ERROR) return ERROR;
	return OK;
}


fprnd(num,result,prec)
char *num, *result;
int prec;

{
int temp;

if ((prec < PREC-1) && (prec > -2) && (num[PREC/2-1])){
   atof(result,"0.5");
   temp=result[PREC/2]=num[PREC/2];
   scale(result,-prec-1,result);
   fpadd(num,result,result);
   if (temp==result[PREC/2]) zfl(result,prec+1);
   else zfl(result,prec+2);
   }
else assign(result,num);
}

_fpand(num,buf,prec)
char *num, *buf;
int prec;

{
char *tmp;
int i;

*buf++ = num[PREC/2] & 1;
tmp = num + PREC/2 -1;
for (i=0; i<PREC/2; i++){
   *buf++ = ((*tmp & 0xf0)>>4)+'0';
   *buf++= (*tmp -- & 0x0f)+'0';
   }
}

_fpxnd(exp,buf,xchr)
int exp;
char *buf, xchr;

{
*buf++ = xchr;
if ((exp -= 64) < 0){
   exp = -exp;
   *buf++ = '-';
   }
else *buf++ = '+';
if (exp<10) *buf++ = '0';
_uspr(&buf,exp,10);
}

_fpespr(putcf,arg1,num,prec)
int (*putcf)();
char *num;
int arg1,prec;

{
char *pnt;
int wcnt;

pnt = num+1;
if (ERROR == (*putcf)(*pnt++,arg1)) return ERROR;
if (prec > 0){
   if (ERROR == (*putcf)('.',arg1)) return ERROR;
   wcnt = PREC-1;
   while (prec --){
      if (wcnt){
         if (ERROR == (*putcf)(*pnt++,arg1)) return ERROR;
         wcnt--;
         }
      else
         if (ERROR == (*putcf)('0',arg1)) return ERROR;
      }
   }
pnt = num + PREC+1; /* wasn't advanced if prec < PREC */
if (ERROR == (*putcf)(*pnt++,arg1)) return ERROR;
if (ERROR == (*putcf)(*pnt++,arg1)) return ERROR;
if (ERROR == (*putcf)(*pnt++,arg1)) return ERROR;
if (ERROR == (*putcf)(*pnt++,arg1)) return ERROR;
return OK;
}

_fpfspr(putcf,arg1,num,exp,prec)
int (*putcf)();
char *num;
int arg1,exp,prec;

{
char *pnt;
int wcnt;

wcnt = PREC;
pnt = num+1;
exp++;
while (exp>0){
   exp--;
   if (wcnt){
      if (ERROR==(*putcf)(*pnt++,arg1)) return ERROR;
      wcnt--;
      }
   else
      if (ERROR==(*putcf)('0',arg1)) return ERROR;
   }
if (prec){
   if (ERROR==(*putcf)('.',arg1)) return ERROR;
   while ((prec) && (exp++)){
      prec--;
      if (ERROR == (*putcf)('0',arg1)) return ERROR;
      }
   while (prec--){
      if (wcnt){
         if (ERROR == (*putcf)(*pnt++,arg1)) return ERROR;
         wcnt--;
         }
      else
         if (ERROR == (*putcf)('0',arg1)) return ERROR;

      }
   }
return OK;
}

char *atof(num,string)
char *num,*string;

{
int temp;
int _sgetc(),_sungetc();

_atof(_sgetc,_sungetc,&string,num,MAXLINE,&temp);
return num;
}

int _atof(get,unget,ioarg, num,width,pk)
int (*get)(), (*unget)(), width;
char *num,*pk;

{
int prec, decades, esign, sign, expval, i;
char wrkspace[PREC], *place;
char peek,temp;

prec = PREC;
place = wrkspace;
expval = esign = sign = 0;   /* corresponds with positive */
decades = -1;

peek = (*get)(ioarg); if (!(width--)) goto done;
if (peek=='-'){
   sign = 1;
   peek = (*get)(ioarg); if (!(width--)) goto done;
   }
else if (peek == '+'){
   peek = (*get)(ioarg); if (!(width--)) goto done;
   }
else if (peek == '.') goto fract0;
else if (!isdigit(peek)) {
   *pk = peek;
   return ERROR;
   }
while (peek=='0') {
   peek = (*get)(ioarg); if (!(width--)) goto done;
   }

/* scan whole portion of number */
while (isdigit(peek)){
   if (prec){ *place++ = peek; prec --; }
   decades++;
   peek = (*get)(ioarg); if (!(width--)) goto done;
   }
if (peek != '.') goto exp;

fract0:
   peek=(*get)(ioarg); if (!(width--)) goto done;
   if (prec == PREC){
      while (peek == '0') {
         decades -= 1;
         peek = (*get)(ioarg); if (!(width--)) goto done;
         }
      }

fractd:
   while (isdigit(peek)){
      if (prec) { *place++ = peek; prec--;}
      peek = (*get)(ioarg); if (!(width--)) goto done;
      }

exp:
   if (toupper(peek) != 'E') goto done;
   peek = (*get)(ioarg); if (!(width--)) goto done;
   if (peek=='-'){
      esign=1;
      peek = (*get)(ioarg); if (!(width--)) goto done;
      }
   else if (peek=='+'){
      peek = (*get)(ioarg); if (!(width--)) goto done;
      }
   while (isdigit(peek)){
      expval=expval*10+(peek & 0x0f);
      peek = (*get)(ioarg); if (!(width--)) goto done;
      }

done:
   if (prec == PREC) {expval= sign = esign = 0;}  /* negative zero not allowed*/
   while (prec--) {*place++ = '0';}
   for (i=0;i<PREC/2;i++){
      temp = (*(--place)) & 0x0f;
      *num++ = ((*(--place)) << 4) + temp;
      }

   expval = (esign)? -expval: expval;
   *num = ((expval + decades + 64) << 1) | sign;
   if (!(*(num-1))) { /*if fraction is zero */
      *num = 0x7e;
      }
   *pk = peek;
   return !ERROR;
}

#define iseof(x) (x==CPMEOF || x==EOF || x==0)

int
_scn(arglist,get,unget,ioarg)
int (*get)(), (*unget)();
int **arglist;
{
	char asgflag, c, base, n, *sptr, *format, matchit;
	char shortf;
        char temp[PREC/2+1];
	int sign, val, width, peek;
	union {
		char byte;
		int word; } ;
	format = *arglist++;	/* format points to the format string */

	n = 0;
	while (1)
	{
	   if (!(c = *format++)) goto alldone;
	   if (isspace(c)) continue;	/* skip white space in format string */
	   if (c!='%') 
	   	{
	   	if(_GetNonWh(get,ioarg,&peek)) goto eofdone;
		if(c!=peek) goto undone;
		}
	   else		/* process conversion */
	    {
		sign = 1; shortf=FALSE;
		if ('*'==*format) {
			format++;
			asgflag = FALSE;}
		else asgflag = TRUE;
		if (isdigit(*format)) width = _gv2(&format);
		else width = 32767;
		if ('l'==*format) format++;		/* no longs */
		switch (c=*format++) {
			case 'x': base = 16;	goto doval;
 			case 'o': base = 8;	goto doval;
			case 'b': base = 2;	goto doval;
			case 'h': shortf = TRUE;		/* short is char */
			case 'd':
			case 'u': base = 10;
				doval:
				if (_GetNonWh(get,ioarg,&peek)) goto eofdone;
				width--;
				if (peek=='-') {
					sign = -1;
					peek=(*get)(ioarg);
					if (!width--) continue;
					}
				if ((val=_bc(peek,base)) == ERROR)
					goto undone;
				while (1) {
					peek = (*get)(ioarg);
					if (iseof(peek) || !width--) break;
					if (peek=='x' && c=='x') continue;
					if ((c = _bc(peek,base)) == 255) break;
					val = val * base + c;
				}
				if (asgflag) {
					val *= sign;
					if (shortf)
						(*arglist++)->byte = val;
					else
						(*arglist++)->word = val;
					n++;}
				if (iseof(peek)) goto eofdone;
				(*unget)(peek,ioarg);
				continue;
                        case 'e':
                        case 'f':
                        case 'g':
                                if (_GetNonWh(get,ioarg,&peek)) goto eofdone;
                                (*unget)(peek,ioarg);
                                if (_atof(get,unget,ioarg,temp,width,&peek)==
                                    ERROR) goto undone;
                                if (asgflag){
                                   assign(*arglist++,temp);
                                   n++;
                                   }
                                if (iseof(peek)) goto eofdone;
                                (*unget)(peek,ioarg);
                                continue;

			case 's': 
				if (_GetNonWh(get,ioarg,&peek)) goto eofdone;
				matchit = ('%'==*format) ? ' ' : *format;
				sptr = *arglist;
				while (1) {
					if (isspace(peek)) break;
					if (peek == matchit) {
						format++;
						break;
					 }
					if (asgflag) *sptr++ = peek;
					if (!--width) break;
					peek=(*get)(ioarg);
					if (iseof(peek)) break;
				 } 
				if (asgflag) {
					n++;
					*sptr = '\0';
					arglist++;
				 }
				if (iseof(peek)) goto eofdone;
				continue;

			case 'c': peek=(*get)(ioarg);
				if (iseof(peek)) goto eofdone;
				if (asgflag) {
					(*arglist++)->byte = peek;
					n++;
				}
				continue;

			case '%':	/* allow % to be read with "%%" */
				if (_GetNonWh(get,ioarg,&peek)) goto eofdone;
				if ('%' != peek) goto undone;
				continue;

			default: goto alldone;
		 }
	    }
	}
	eofdone:	(*unget)(CPMEOF,ioarg);
			return n ? n : EOF;
	undone:		(*unget)(peek,ioarg);
	alldone:	return n;
}

char *exp(x,y,result)
char *x,*y,*result;

{
char local[PREC/2+1];
return lginv(fpmult(log(x,local),y,local),result);
}

char *lninv(x,result)
char *x,*result;
{
char local[PREC/2+1];
char **const;

const = lcnst();
return lginv(fpmult(x,const[16],local),result);
}

char *lginv(x,result)
char *x,*result;

{
char local[PREC/2+1];
char m[PREC/2+1];
char m0[PREC/2+1];
char **const;
int i,mg;

const = lcnst();
assign(m,const[10]);
mg = ftoi(x);
if (mg) fpabs(fpsub(x,itof(m0,mg),local),local);
else fpabs(x,local);
if (!local[PREC/2-1]) {
   assign(result,const[10]);
   return scale(result,mg,result);
   }
else{
   for(i=0;i<=7;i++){
      while (fscmp(local,const[i])!=1){
         fpsub(local,const[i],local);
         scale(m,-i,m0);
         fpadd(m,m0,m);
         }
      }
   }
fpmult(local,const[14],local);
fpmult(local,local,m0);
fpdiv(m0,const[15],m0);
fpmult( fpadd(fpadd(const[10], local, local),
              m0,
              result),
        m,
        result);
if (fscmp(x,const[8])==1) fpdiv(const[10],result,result);
if (mg) scale(result,mg,result);
return result;
}
      


char *ln(x,result)
char *x,*result;

{
char **const;
char temp[PREC/2+1];

const = lcnst();
log(x,temp);
fpmult(temp,const[14],result);
return result;
}

char *log(x,result)
char *x,*result;
{
int xpon;
char local[PREC/2+1];

if (xpon=mag(x)){
   scale(x,-xpon,local);
   _restlg(local,result);
   }
else
   _restlg(x,result);
return fpadd(result,itof(local,xpon),result);
}


char *_restlg(x,result)
char *x,*result;

{   
int i;
char local[PREC/2+1];
char p[8][PREC/2+1];
char s[PREC/2+1];
char x0[PREC/2+1];
char t[PREC/2+1];
char t2[PREC/2+1];
char **const;
const = lcnst();
assign(local,x);
assign(p[0],const[8]);
while (fscmp(local,const[11])>0){
   fpadd(local,local,local);
   fpadd(p[0],const[0],p[0]);
   }
fpsub(const[12],local,local);
for (i=1;i<=7;i++){
   assign(p[i],const[8]);
   while (fscmp(local,scale(const[10],1-i,t))<1) {
      scale(local,-i,t2);
      fpsub(fpadd(local,t2,local),t,local);
      fpadd(p[i],const[i],p[i]);
      }
   }
fpdiv(fpmult(const[9],local,t2),fpsub(const[13],local,t),t2);
for (i=7;i>=0;i--) {
   fpadd(t2,p[i],t2);
   }
return fpsub(const[10],t2,result);
}


int abs(x)
int x;

{
return (x>0)? x: 0-x;
}

char *fpabs(num,out)
char *num,*out;
{
if (num != out) assign(out,num);
out[PREC/2] = out[PREC/2] & 0xFE;
return out;
}

/*
		assign
assigns the second variable to the first
*/

char *assign(dest,source)

char *dest, *source;

{
char *temp;
int i;

if (source == dest) return;
temp = dest;
for (i=0;i<PREC/2 +1;i++) *dest++ = *source++;
return temp;
}


char *errm()

{
int sval;

char *z,*u,*o, *e, *static;

static = "                                                ";

z="DZ";
u="UF";
o="OF";
e="";

if (sval = fstat()){
	sprintf(static,"%s%s%s ERROR",
	  ((sval & 1) ? z : e), ((sval & 2) ? o : e),
	  ((sval & 4) ? u : e));
	return static;
	}
else return e;
}

char *itof(result,source)
char *result;
int source;

{
char buf[15];

sprintf(buf,"%d",source);
return atof(result,buf);
}

int ftoi(fnum)
char *fnum;   /* must point to a valid bcd number */

{
char buf[69+PREC];
sprintf(buf,"%f",fnum);
return atoi(buf);
}


int fscmp(num1,num2)
char *num1, *num2;

{
char sign1, sign2;

sign1=num1[PREC/2] & 1;
sign2=num2[PREC/2] & 1;
if (sign1 == sign2)
	return ((sign1)? fpcmp(num2,num1):fpcmp(num1,num2));
if (sign1) return 1;
return -1;
}

char *fneg(num,out)
char *num;
char *out;

{
if (num != out) assign(out,num);
out[PREC/2] = out[PREC/2] ^ 1;
return out;
}

char *ftrunc(num,result)
char *num, *result;

{
char buf[69+PREC];
sprintf(buf,"%f",num);
return atof(result, buf);
}


/*
			scale

scales (multiplies by manipulating exponents) num by
10 ^ k where k is a an integer.  Stores product in result.
num and result may point to the same number, in which
case num is modified. Returns a pointer to result. 

This version does not check for overflow or underflow!!!
*/

char *scale(num, k, result)
char *num, *result;
int k;

{
int exp, sign;

if (num != result) assign (result,num);
exp = num[PREC/2] >> 1;
sign = num[PREC/2] & 1;
exp = exp + k;
result[PREC/2] = (exp << 1) | sign;
return result;
}


/*
Rounds num (adds 5) in the position to the right of
the pos'th digit of the fraction (if any). Zero fills
from the rounded digit (inclusive) to the right. 
May be called with num == result.

*/

char *frnd(num,pos,result)
char *num, *result;
int pos;

{
int exp, k;
char five[PREC/2 +1];

if (result != num) assign(result,num);
exp = (result[PREC/2] >> 1) - BIAS;
/* check that requested rounding lies within precision
   of representation */
if (pos > (PREC - exp)) return result;
	/* rounding requested in digit to right 
	   of least significant nibble */
if (pos < (0 - exp)) return atof(result, "0");
	/* rounding requested too far left
	   of precision */

/* now adjust pos to reflect actual position within mantissa */
k = pos + exp + 1;
/* make sure rounding required before calling fpadd */
if (((result[((PREC-1)-k)/2]>>((k & 1)?0:4)) & 0x0f) > 4){
	if (result[PREC/2] & 1) scale(atof(five,"-.5"),0-pos,five);
	else scale(atof(five,"0.5"),0-pos,five);
	fpadd(five, result, result);
	}
/* now wipe out the garbage at right */
return zfl(result,k);
}
	


/*

		zfl

this low-level routine is called by several other
functions. It zero's all digits right of the kth in
the floating point fractional part of num. THIS
MODIFIES THE INPUT, unlike other functions in this
package. Returns a pointer to num.
If k > PREC, does nothing.
If k < 0, does nothing.

*/

char *zfl(num,k)
char *num;
int k;

{
char *ptr;
int i;

if ((k < 0) || (k > PREC -1)) return num;
ptr = num; /*start at least sig. byte*/
for (i=(k+1)/2; i<PREC/2; i++) *ptr++ = 0;
if (k&1) {
	*ptr = *ptr & 0xf0;
	ptr--;
	}
return num;
}

/*
		mag
returns an integer corresponding to the magnitude of
the floating point number x
*/
int mag(x)
char *x;
{return ((x[PREC/2] >> 1) -BIAS);}


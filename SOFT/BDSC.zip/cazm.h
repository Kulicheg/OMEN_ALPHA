/*
================================================================
CAZM.H, Customizable definitions for CAZM.C v0.3a (3/92)

Set the following definitions to your preferences.  Modification
of CAZM.C should not be necessary for normal use.

See CAZM.DOC and CAZM.UPD.
================================================================
*/

#define ZILOG	TRUE	/* set true for Z80ASM Zilog mnemonics */
			/* false for Z80.LIB "extended Intel" */

#if !ZILOG		/* leave this stuff alone (reserved) */
#define INTEL	TRUE
#else
#define INTEL	FALSE
#endif

#if INTEL
#define SLRMAC	TRUE	/* set true if you are using SLRMAC */
#endif

/* Here are some items you will probably want to edit: */

#if ZILOG		/* for "Zilog-style" input and output: */

#define DEFBOP	"DB"		/* pseudo-op for Z80 DEFB */
#define DEFCOP	"DC"		/* pseudo-op for Z80 DEFC */
#define DEFLOP	"ASET"		/* pseudo-op for Z80 DEFL */
#define DEFSOP	"DS"		/* pseudo-op for Z80 DEFS */
#define DEFWOP	"DW"		/* pseudo-op for Z80 DEFW */
#define DEFZOP	"DEFZ"		/* pseudo-op for Z80 DEFZ */
#define JUMPOP	"JP"		/* non-conditional jump op */
#define CAZMEXT	".CAZ"		/* extension on input files */
#define ASMEXT	".Z80"		/* extension on output files */

#else			/* for "Intel-style" input and output: */

#define DEFBOP	"DB"		/* pseudo-op for Z80 DEFB */
#define DEFCOP	"DC"		/* pseudo-op for Z80 DEFC */
#define DEFLOP	"SET"		/* pseudo-op for Z80 DEFL */
#define DEFSOP	"DS"		/* pseudo-op for Z80 DEFS */
#define DEFWOP	"DW"		/* pseudo-op for Z80 DEFW */
#define DEFZOP	"DZ"		/* pseudo-op for Z80 DEFZ */
#define JUMPOP	"JMP"		/* non-conditional jump op */
#define CAZMEXT	".CSM"		/* extension on input files */
#define ASMEXT	".MAC"		/* extension on output files */

#endif

#define DEFDIR	""		/* default "include file" directory */
				/* use "NAME:", or "DU:" for specific dir, */
				/* or "" for ZSDOS path search */

#define LIBEXT	".LIB"		/* default extension for library files */

#define SUBFILE "$$$.SUB"	/* Submit file to erase on error. To not */
				/* erase any, use a null string ("") */

#define CONTROL_C '\03'		/* Abort character */

/* The following probably won't need changing unless you get a CAZM overflow
   error message telling you otherwise.  These values are more than adequate
   for anything in the release files: */

#define	SYMMAX	500		/* maximum number of absolute symbols */
#define FUNCMAX	100		/* maximum number of functions */
#define XFMAX	25		/* max no. of extern funcs in one function */
#define LBLMAX	150		/* max no. of local labels in one function */
#define TEXTMAX 2000		/* max text for labels & extern func. names */
#define NESTMAX	3		/* max nesting of includes */
#define ARGMAX	10		/* max number of op arguments (allow for */
				/* multi-byte DB args, complex conditional */
				/* statements, etc.) */

/* Carefully examine the initrelop() and initrjump() tables in CAZM.C before
   changing these: */

#if ZILOG		/* for Zilog mnemonics: */

#define RELOPMAX 4	/* max no. of relocatable opcode names */
#define RJUMPMAX 2	/* max no. of relative jump opcode names */

#else			/* for Intel mnemonics: */

#define RELOPMAX 36	/* max no. of relocatable opcode names */
#define RJUMPMAX 6	/* max no. of relative jump opcode names */

#endif

/* 
================================================================ 
The balance of this file defines global data used by the CAZM.C 
and TABLE.C modules.  Do not change anything here unless you 
have made corresponding changes in those files. 
================================================================ 
*/

#define FLAG	char		/* for true/false variables */

/* Global data used throughout processing of the entire input file: */

FILE	*fp[NESTMAX];		/* input file pointer table */
FILE	*infp;			/* currently active input file pointer */
FILE	*outfp;			/* file pointer for output file */
char	*curfile;		/* pointer to name of current input file */
char	infile[NESTMAX][30];	/* filenames for current input files */
int	nestlev;		/* nest level: 0 for top, max NESTMAX-1 */
char	*sym[SYMMAX];		/* table of absolute symbols */
int	syms;			/* # of entries in sym */
char	*relop[RELOPMAX];	/* table of relocatable ops */
int	relops;			/* # of entries in relop */
char	*rjump[RJUMPMAX];	/* table of relative jump ops */
int	rjumps;			/* # of entries in rjump */
char	*func[FUNCMAX];		/* list of functions in the source file */
int	funcs;			/* # of entries in func */
int	lino;			/* line number value for error reporting */
FLAG	infunc;			/* true if currently processing a function */
FLAG	errf;			/* true if an error has been detected */
FLAG	comments;		/* true to save source comments in output */
FLAG	verbose;		/* true to insert CAZM comments in output */
FLAG	debug;			/* true if debugging option given */

/* Global data used during the processing of a single function
   in the source file: */

char	*xfunc[XFMAX];		/* external functions for one function */
int	xfuncs;			/* number of entries in xfunc */

struct {
	char *lblnam;		/* name of function label */
	char defined;		/* whether it has been defined yet */
} lbl[LBLMAX];

int	labels;			/* number of local labels in a function */
char	textbuf[TEXTMAX],	/* where text of needed function names */
	*textp;			/*  and function labels go */
char 	linebuf[MAXLINE],	/* text line buffers */
	workbuf[MAXLINE],
	parsbuf[MAXLINE];
char	*curfunc;		/* pointer to name of current function */
int	relocs;			/* relocation object count for a function */
FLAG	pastxfs;		/* true if we've passed all needed function */
				/*  declarations ("external" pseudo ops) */
int	args;			/* values set by the "parse_line" function */
char	*label,
	*op,
	*argp,
	*arg[ARGMAX];

/* EOF: CAZM.H */
